﻿using System;

namespace WpfPrac1.Models
{
    public class UserInfo
    {
        public DateTime BirthDate { get; set; }

        public int Age => CalculateAge();

        public string WesternZodiac => GetWesternZodiac();
        public string ChineseZodiac => GetChineseZodiac();

        private int CalculateAge()
        {
            DateTime today = DateTime.Today;
            int age = today.Year - BirthDate.Year;
            if (BirthDate > today.AddYears(-age)) age--;
            return age;
        }

        private string GetWesternZodiac()
        {
            int day = BirthDate.Day;
            int month = BirthDate.Month;
            return month switch
            {
                1 => day <= 19 ? "Козеріг" : "Водолій",
                2 => day <= 18 ? "Водолій" : "Риби",
                3 => day <= 20 ? "Риби" : "Овен",
                4 => day <= 19 ? "Овен" : "Телець",
                5 => day <= 20 ? "Телець" : "Близнюки",
                6 => day <= 20 ? "Близнюки" : "Рак",
                7 => day <= 22 ? "Рак" : "Лев",
                8 => day <= 22 ? "Лев" : "Діва",
                9 => day <= 22 ? "Діва" : "Терези",
                10 => day <= 22 ? "Терези" : "Скорпіон",
                11 => day <= 21 ? "Скорпіон" : "Стрілець",
                12 => day <= 21 ? "Стрілець" : "Козеріг",
                _ => "Невідомо"
            };
        }

        private string GetChineseZodiac()
        {
            string[] chineseZodiacs = { "Мавпа", "Півень", "Собака", "Свиня", "Щур", "Бик", "Тигр", "Кролик", "Дракон", "Змія", "Кінь", "Коза" };
            return chineseZodiacs[BirthDate.Year % 12];
        }
    }
}
