﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;

namespace WpfPrac1.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private DateTime _birthDate = DateTime.Today;
        private string _ageMessage;
        private string _zodiacMessage;
        private string _chineseZodiacMessage;

        public DateTime BirthDate
        {
            get => _birthDate;
            set
            {
                _birthDate = value;
                OnPropertyChanged(nameof(BirthDate));
            }
        }

        public string AgeMessage
        {
            get => _ageMessage;
            private set
            {
                _ageMessage = value;
                OnPropertyChanged(nameof(AgeMessage));
            }
        }

        public string ZodiacMessage
        {
            get => _zodiacMessage;
            private set
            {
                _zodiacMessage = value;
                OnPropertyChanged(nameof(ZodiacMessage));
            }
        }

        public string ChineseZodiacMessage
        {
            get => _chineseZodiacMessage;
            private set
            {
                _chineseZodiacMessage = value;
                OnPropertyChanged(nameof(ChineseZodiacMessage));
            }
        }

        public ICommand CalculateCommand => new RelayCommand(CalculateAgeAndZodiac);

        private void CalculateAgeAndZodiac()
        {
            var user = new Models.UserInfo { BirthDate = BirthDate };

            if (user.Age < 0 || user.Age > 135)
            {
                MessageBox.Show("Введена дата некоректна!", "Помилка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            AgeMessage = $"Ваш вік: {user.Age}";
            ZodiacMessage = $"Західний знак зодіаку: {user.WesternZodiac}";
            ChineseZodiacMessage = $"Китайський знак зодіаку: {user.ChineseZodiac}";

            if (BirthDate.Month == DateTime.Today.Month && BirthDate.Day == DateTime.Today.Day)
            {
                MessageBox.Show("З Днем народження! 🎉", "Вітання", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    public class RelayCommand : ICommand
    {
        private readonly Action _execute;
        public RelayCommand(Action execute) => _execute = execute;
        public bool CanExecute(object parameter) => true;
        public void Execute(object parameter) => _execute();
        public event EventHandler CanExecuteChanged;
    }
}
